﻿using System;

public interface IPrime
{
    IList<int> GetPrimeList(int number);
}
