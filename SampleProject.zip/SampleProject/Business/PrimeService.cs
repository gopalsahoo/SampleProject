﻿using Business.Interface;

public class PrimeService : IPrime
{
    public IList<int> GetPrimeNumber(int number)
    {
        var result = new List<int>();
        if (number <= 100)
        {
            int i;
            for (i = 2; i <= number; i++)
            {
                var isPrime = 1;
                int j;
                for (j = 2; j <= i / 2; j++)
                {
                    if (i % j == 0)
                    {
                        isPrime = 0;
                        break;
                    }
                }

                if (isPrime == 1)
                {
                    result.Add(i);
                }
            }
        }

        var output = result.OrderByDescending(x=>x);
        return output.ToList();
    }
}
