﻿using Business.Interface;

namespace SampleProject
{
    public static class ServiceCollectionExtension
    {
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            return services.AddScoped<IPrime, PrimeService>();
        }
    }
}
