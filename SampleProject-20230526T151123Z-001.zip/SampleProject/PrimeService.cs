﻿using System;

public class PrimeService : IPrime
{
	

}
