﻿using Business.Interface;
using Microsoft.AspNetCore.Mvc;

namespace SampleProject.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SampleController : ControllerBase
    {
        private readonly IPrime _iPrime;

        public SampleController(IPrime iPrime)
        {
            _iPrime = iPrime;
        }

        [HttpGet(Name = "get-prime-number-list")]
        [Route("{number}")]
        public IList<int> GetPrimeNumber(int integer)
        {
            return _iPrime.GetPrimeNumber(integer);
        }
    }
}
